import React from 'react';
    import { Link } from 'react-router-dom';
    import { motion } from 'framer-motion';

    const Navbar = () => {
      return (
        <motion.nav
          className="bg-lightNavy sticky top-0 z-50 backdrop-blur-sm bg-opacity-90"
          initial={{ y: -100 }}
          animate={{ y: 0 }}
          transition={{ duration: 0.5, ease: [0.1, 0.4, 0.2, 1] }}
        >
          <div className="container mx-auto px-6 md:px-12 lg:px-24 py-4 flex justify-between items-center">
            <Link to="/" className="text-xl font-bold text-primary">My Portfolio</Link>
            <div className="space-x-6">
              <Link to="/about" className="hover:text-primary transition-colors duration-200">About</Link>
              <Link to="/projects" className="hover:text-primary transition-colors duration-200">Projects</Link>
              <Link to="/contact" className="hover:text-primary transition-colors duration-200">Contact</Link>
            </div>
          </div>
        </motion.nav>
      );
    };

    export default Navbar;
