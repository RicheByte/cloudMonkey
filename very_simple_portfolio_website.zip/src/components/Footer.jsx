import React from 'react';
    import { FaGithub, FaLinkedin } from 'react-icons/fa';

    const Footer = () => {
      return (
        <footer className="bg-lightNavy text-center py-8 relative z-10">
          <div className="container mx-auto px-6 md:px-12 lg:px-24 flex justify-center space-x-6 mb-4">
            <a href="#" className="text-gray-400 hover:text-primary transition-colors duration-200">
              <FaGithub size={20} />
            </a>
            <a href="#" className="text-gray-400 hover:text-primary transition-colors duration-200">
              <FaLinkedin size={20} />
            </a>
          </div>
          <p className="text-sm text-gray-400">Designed & Built by Your Name</p>
        </footer>
      );
    };

    export default Footer;
