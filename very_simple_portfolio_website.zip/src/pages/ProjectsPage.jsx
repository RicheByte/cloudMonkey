import React from 'react';
    import { motion } from 'framer-motion';
    import project1Image from '../assets/project1.jpg';
    import project2Image from '../assets/project2.jpg';
    import project3Image from '../assets/project3.jpg';

    const ProjectsPage = () => {
      const projects = [
        {
          id: 1,
          name: 'Project 1',
          description: 'A full-stack web application built with React, Node.js, and Tailwind CSS. This project focuses on user authentication and data management.',
          tech: ['React', 'Node.js', 'Tailwind CSS', 'MongoDB'],
          image: project1Image,
        },
        {
          id: 2,
          name: 'Project 2',
          description: 'A mobile-first application developed using Vue.js and Firebase. This project emphasizes real-time data synchronization and user engagement.',
          tech: ['Vue.js', 'Firebase', 'JavaScript'],
          image: project2Image,
        },
        {
          id: 3,
          name: 'Project 3',
          description: 'An enterprise-level application developed with Angular and Express.js. This project highlights scalability and performance optimization.',
          tech: ['Angular', 'Express.js', 'TypeScript', 'PostgreSQL'],
          image: project3Image,
        },
      ];

      return (
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="text-3xl font-bold text-white mb-8">Some Things I’ve Built</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {projects.map(project => (
              <motion.div
                key={project.id}
                className="bg-lightNavy p-6 rounded-md shadow-md hover:shadow-lg transition-shadow duration-300 relative overflow-hidden"
                whileHover={{ scale: 1.03 }}
              >
                <img src={project.image} alt={project.name} className="absolute inset-0 w-full h-full object-cover opacity-20" />
                <div className="relative z-10">
                  <h3 className="text-xl font-semibold text-white mb-2">{project.name}</h3>
                  <p className="text-gray-400 mb-4">{project.description}</p>
                  <ul className="flex flex-wrap">
                    {project.tech.map(tech => (
                      <li key={tech} className="bg-lightestNavy text-primary px-2 py-1 mr-2 mb-2 rounded">
                        {tech}
                      </li>
                    ))}
                  </ul>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.section>
      );
    };

    export default ProjectsPage;
