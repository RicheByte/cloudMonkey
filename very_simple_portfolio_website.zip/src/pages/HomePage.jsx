import React from 'react';
    import { motion } from 'framer-motion';
    import heroImage from '../assets/hero-bg.jpg';

    const HomePage = () => {
      return (
        <motion.section
          className="relative flex flex-col items-start justify-center min-h-[calc(100vh-120px)] overflow-hidden"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 1, delay: 0.5 }}
        >
          <div
            className="absolute inset-0 bg-cover bg-center z-0"
            style={{ backgroundImage: `url(${heroImage})`, filter: 'brightness(0.5)' }}
          />
          <div className="relative z-10">
            <motion.h5
              className="text-primary font-mono mb-4"
              initial={{ y: -20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.5, delay: 1 }}
            >
              Hi, my name is
            </motion.h5>
            <motion.h1
              className="text-white text-5xl md:text-7xl font-bold mb-4"
              initial={{ y: -20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.5, delay: 1.2 }}
            >
              Your Name.
            </motion.h1>
            <motion.h2
              className="text-gray-400 text-3xl md:text-5xl font-bold mb-8"
              initial={{ y: -20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.5, delay: 1.4 }}
            >
              I build things for the web.
            </motion.h2>
            <motion.p
              className="text-gray-400 max-w-lg mb-8"
              initial={{ y: -20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.5, delay: 1.6 }}
            >
              I'm a software developer specializing in building (and occasionally designing) exceptional digital experiences. Currently, I’m focused on building accessible, human-centered products.
            </motion.p>
            <motion.a
              href="/projects"
              className="inline-block text-primary border border-primary rounded py-2 px-6 hover:bg-opacity-10 hover:bg-primary transition-colors duration-300"
              initial={{ y: -20, opacity: 0 }}
              animate={{ y: 0, opacity: 1 }}
              transition={{ duration: 0.5, delay: 1.8 }}
            >
              Check out my projects!
            </motion.a>
          </div>
        </motion.section>
      );
    };

    export default HomePage;
