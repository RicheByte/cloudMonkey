import React from 'react';
    import { motion } from 'framer-motion';
    import { FaEnvelope, FaLinkedin, FaGithub } from 'react-icons/fa';

    const ContactPage = () => {
      return (
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="text-3xl font-bold text-white mb-8">Get In Touch</h2>
          <p className="text-gray-400 mb-8">
            I'm currently open to new opportunities and collaborations. Whether you have a project idea or just want to say hi, feel free to reach out!
          </p>
          <motion.div
            className="bg-lightNavy p-8 rounded-md shadow-md"
            whileHover={{ scale: 1.02 }}
            transition={{ duration: 0.3 }}
          >
            <div className="flex items-center mb-4">
              <FaEnvelope className="mr-4 text-primary" size={20} />
              <a href="mailto:your.email@example.com" className="text-gray-400 hover:text-primary transition-colors duration-200">
                your.email@example.com
              </a>
            </div>
            <div className="flex items-center mb-4">
              <FaLinkedin className="mr-4 text-primary" size={20} />
              <a href="https://www.linkedin.com/in/yourprofile" target="_blank" className="text-gray-400 hover:text-primary transition-colors duration-200">
                LinkedIn
              </a>
            </div>
            <div className="flex items-center">
              <FaGithub className="mr-4 text-primary" size={20} />
              <a href="https://github.com/yourusername" target="_blank" className="text-gray-400 hover:text-primary transition-colors duration-200">
                GitHub
              </a>
            </div>
          </motion.div>
        </motion.section>
      );
    };

    export default ContactPage;
