import React from 'react';
    import { motion } from 'framer-motion';

    const AboutPage = () => {
      return (
        <motion.section
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
        >
          <h2 className="text-3xl font-bold text-white mb-8">About Me</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div>
              <p className="text-gray-400 mb-4">
                Hello! My name is Your Name and I enjoy creating things that live on the internet. My interest in web development started back in high school when I was editing themes on Tumblr — turns out hacking together a custom reblog button taught me a lot about HTML & CSS!
              </p>
              <p className="text-gray-400 mb-4">
                Fast-forward to today, and I’ve had the privilege of working at an advertising agency, a start-up, a huge corporation, and now a tech-focused bootcamp. My main focus these days is building accessible, inclusive products and digital experiences at V School for a variety of clients.
              </p>
              <p className="text-gray-400 mb-4">
                I'm also actively involved in the tech community, mentoring aspiring developers and contributing to open-source projects.
              </p>
            </div>
            <div>
              <p className="text-gray-400 mb-4">Here are a few technologies I've been working with recently:</p>
              <ul className="list-disc pl-5 text-primary grid grid-cols-2 gap-2">
                <li>JavaScript (ES6+)</li>
                <li>React</li>
                <li>Node.js</li>
                <li>Tailwind CSS</li>
                <li>HTML & CSS</li>
                <li>Git</li>
              </ul>
            </div>
          </div>
        </motion.section>
      );
    };

    export default AboutPage;
