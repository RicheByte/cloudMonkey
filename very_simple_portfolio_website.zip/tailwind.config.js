/** @type {import('tailwindcss').Config} */
    export default {
      content: [
        "./index.html",
        "./src/**/*.{js,ts,jsx,tsx}",
      ],
      theme: {
        extend: {
          fontFamily: {
            'sans': ['ui-sans-serif', 'system-ui', '-apple-system', 'BlinkMacSystemFont', 'Segoe UI', 'Roboto', 'Helvetica Neue', 'Arial', 'Noto Sans', 'sans-serif', 'Apple Color Emoji', 'Segoe UI Emoji', 'Segoe UI Symbol', 'Noto Color Emoji'],
            'serif': ['ui-serif', 'Georgia', 'Cambria', '"Times New Roman"', 'Times', 'serif'],
            'mono': ['ui-monospace', 'SFMono-Regular', 'Menlo', 'Monaco', 'Consolas', '"Liberation Mono"', '"Courier New"', 'monospace'],
            'display': ['Oswald', ...require('tailwindcss/defaultTheme').fontFamily.sans],
            'body': ['"Open Sans"', ...require('tailwindcss/defaultTheme').fontFamily.sans],
          },
          colors: {
            primary: '#64ffda',
            secondary: '#ccd6f6',
            background: '#0a192f',
            lightBackground: '#112240',
            accent: '#f9f871',
            darkNavy: '#020c1b',
            navy: '#0a192f',
            lightNavy: '#172a45',
            lightestNavy: '#303C55',
            slate: '#8892b0',
            lightSlate: '#a8b2d1',
            lightestSlate: '#ccd6f6',
            white: '#e6f1ff',
          },
        },
      },
      plugins: [],
    }
